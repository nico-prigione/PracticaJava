package ar.com.gugler.sgc.modelo;



public class Universidad {
	

}
