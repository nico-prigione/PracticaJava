
public class EjercicioD {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for(int i=14;i>5;i--) {
			if(i%2==0) {
				System.out.println(i);
			}
			
		}

	}

}
