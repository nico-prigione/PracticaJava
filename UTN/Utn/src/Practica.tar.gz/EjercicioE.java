import java.util.*;
public class EjercicioE {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double ingresoAlto=489.083;
		Scanner entrada=new Scanner(System.in);
		
		System.out.println("Ingrese su sueldo neto: ");
		
		int dato=entrada.nextInt();
		
		boolean claseAlta=false;
		
		System.out.println("Indique cuanto autos posee con antiguedad menor a 5 años ");
		int dato2=entrada.nextInt();
		System.out.println("Indique si posee Inmuebles ");
		int dato3=entrada.nextInt();
		System.out.println("Indique cuantas embarcaciones de lujo posee ");
		int dato4=entrada.nextInt();
		
		if(dato2!=0 && dato3!=0 && dato4!=0) {
			claseAlta=true;
		}else if(dato2!=0 || dato3!=0 || dato4!=0) {
			claseAlta=false;
		}
		
		if(claseAlta==true) {
			System.out.println("Ud es Clase Alta. ");
		}else {
			System.out.println("Ud es Clase Media. ");
		}

	}
		
		
}


